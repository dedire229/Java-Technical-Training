# 05 — Encapsulation — Class Diagram

## Concept
**Private fields + public methods.** Protect internal state from being put into an invalid state.

## Diagram

```
┌────────────────────────────────────────────────┐
│                  BankAccount                   │
├────────────────────────────────────────────────┤
│  - balance : double              ◄── PRIVATE   │   ✘  acct.balance = -100;  // nope
│  - owner   : String                             │
├────────────────────────────────────────────────�
│  + BankAccount(owner, openingBalance)           │
│  + deposit(amount)      : void                  │
│  + withdraw(amount)     : void                  │   ✔ controlled gateway
│  + getBalance()         : double                │
│  + getOwner()           : String                │
└────────────────────────────────────────────────┘
                  ▲
                  │  callers see only this PUBLIC surface
                  │
         ┌────────┴────────┐
         │  Main / Tests   │
         └─────────────────┘
```

### What encapsulation buys you
| Concern | Without encapsulation | With encapsulation |
|---|---|---|
| Invalid state | `acct.balance = -50` | rejected by `withdraw()` |
| Field rename | breaks all callers | only internal change |
| Validation | scattered | in one place |
| Read-only fields | impossible | no setter + getter only |

### Visual cue
The thick border around `BankAccount` symbolizes that **what's inside is hidden**; only the public methods on the surface are accessible from outside.
