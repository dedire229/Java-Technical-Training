// ============================================================
// 05 - ENCAPSULATION
// ============================================================
// "Make your instance variables private.
//  Provide public getters/setters to control access."
//                                  — Head First Java
//
// Encapsulation = data hiding + controlled access.
// Protects the object from being put into an invalid state.
// ============================================================

public class BankAccount {
    // ---- PRIVATE state: no one can touch directly from outside ----
    private double balance;
    private String owner;

    public BankAccount(String owner, double openingBalance) {
        this.owner = owner;
        if (openingBalance < 0) {
            System.out.println("Can't open account with negative balance.");
            this.balance = 0;
        } else {
            this.balance = openingBalance;
        }
    }

    // ---- PUBLIC methods are the controlled gateway ----
    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Deposit must be positive.");
            return;
        }
        balance += amount;
        System.out.println("Deposited $" + amount);
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal must be positive.");
            return;
        }
        if (amount > balance) {
            System.out.println("Insufficient funds.");
            return;
        }
        balance -= amount;
        System.out.println("Withdrew $" + amount);
    }

    // ---- Read-only getter (no setter!) ----
    public double getBalance() {
        return balance;
    }

    public String getOwner() {
        return owner;
    }

    public static void main(String[] args) {
        BankAccount acct = new BankAccount("Alice", 1000);
        System.out.println("Owner: " + acct.getOwner());
        System.out.println("Balance: $" + acct.getBalance());

        acct.deposit(500);
        acct.withdraw(200);
        acct.withdraw(9999);   // rejected — protected by encapsulation
        acct.deposit(-50);     // rejected

        System.out.println("Final balance: $" + acct.getBalance());

        // acct.balance = 1_000_000; // <-- COMPILER ERROR: balance has private access
    }
}
