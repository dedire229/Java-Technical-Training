# 09 — Abstract Classes — Class Diagram

## Concept
A class marked `abstract` can have **unimplemented methods** that subclasses MUST fill in. You **cannot instantiate** an abstract class.

## Diagram

```
                       ┌──────────────────────────────────────┐
                       │   «abstract» Shape                   │   ◄── can't say: new Shape(...)
                       ├──────────────────────────────────────┤
                       │  # color : String                    │
                       ├──────────────────────────────────────�
                       │  + setColor(c) : void                │   ◄── concrete (shared)
                       │  + getColor()   : String             │
                       │  + area()       : double «abstract»  │   ◄── MUST be implemented
                       │  + perimeter()  : double «abstract»  │
                       └───────────────┬─────────────┬────────�
                                       │             │
                          ───extends────┤             ├────extends───
                                       │             │
                                       ▼             ▼
                       ┌────────────────────┐  ┌──────────────────────┐
                       │       Circle       │  │      Rectangle       │
                       ├────────────────────┤  ├──────────────────────┤
                       │ - radius : double  │  │ - width  : double    │
                       ├────────────────────┤  │ - height : double    │
                       │ + area()           │  │ + area()             │
                       │   → πr²            │  │   → w × h            │
                       │ + perimeter()      │  │ + perimeter()        │
                       │   → 2πr            │  │   → 2(w + h)         │
                       └────────────────────┘  └──────────────────────┘
```

### Polymorphic use
```java
Shape[] shapes = { new Circle("red", 5), new Rectangle("blue", 4, 6) };
for (Shape s : shapes) {
    printShapeInfo(s);   // calls the right area()/perimeter()
}
```

### Abstract vs Interface — when to pick which?
- **Abstract class** — when subclasses share **state** and **concrete behavior** (e.g., `color`, `setColor()`).
- **Interface** — when you only want to define a **pure contract** (e.g., `Comparable`, `Serializable`).
