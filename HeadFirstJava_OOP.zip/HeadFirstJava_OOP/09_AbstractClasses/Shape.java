// ============================================================
// 09 - ABSTRACT CLASSES
// ============================================================
// "When a class is `abstract`, it can have UNIMPLEMENTED methods
//  that subclasses MUST fill in. You can't make an instance of
//  an abstract class."
//                                  — Head First Java
//
// Abstract classes can hold:
//   - abstract methods (no body)
//   - concrete methods (with body)
//   - instance variables
// ============================================================

abstract class Shape {
    protected String color;

    public Shape(String color) {
        this.color = color;
    }

    // Concrete method shared by all shapes
    public void setColor(String c) {
        this.color = c;
    }

    public String getColor() {
        return color;
    }

    // Abstract — no body. Each Shape MUST define its own.
    public abstract double area();
    public abstract double perimeter();
}

class Circle extends Shape {
    private double radius;

    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;
    }

    @Override
    public double perimeter() {
        return 2 * Math.PI * radius;
    }
}

class Rectangle extends Shape {
    private double width, height;

    public Rectangle(String color, double w, double h) {
        super(color);
        this.width = w;
        this.height = h;
    }

    @Override
    public double area() {
        return width * height;
    }

    @Override
    public double perimeter() {
        return 2 * (width + height);
    }
}

class AbstractClassDemo {
    public static void main(String[] args) {
        // Shape s = new Shape("red");  // <-- COMPILE ERROR: can't instantiate abstract

        Shape circle = new Circle("red", 5.0);
        Shape rect   = new Rectangle("blue", 4.0, 6.0);

        printShapeInfo(circle);
        printShapeInfo(rect);
    }

    static void printShapeInfo(Shape s) {
        System.out.println(s.getColor() + " shape — area: " +
                           String.format("%.2f", s.area()) +
                           ", perimeter: " +
                           String.format("%.2f", s.perimeter()));
    }
}
