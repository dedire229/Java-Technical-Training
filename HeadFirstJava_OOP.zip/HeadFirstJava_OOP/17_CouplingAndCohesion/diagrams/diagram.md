# 17 — Coupling & Cohesion — Class Diagram

## Concept
- **Coupling** — how much one class *knows* about another. **Loose** is good.
- **Cohesion** — how focused a class's responsibilities are. **High** is good.

## Diagram

```
   ❌ TIGHT COUPLING (bad)
   ────────────────────────

        ┌──────────────────────────────┐
        │       TightOrderProcessor    │
        ├──────────────────────────────┤
        │ - gmail : GmailService = new │
        │           GmailService()     │   ◄── HARD-CODED dependency
        ├──────────────────────────────┤
        │ + placeOrder(item)           │   ──►  gmail.send(...)
        └──────────────────┬───────────┘
                           │ directly creates
                           ▼
                  ┌─────────────────┐
                  │   GmailService  │
                  └─────────────────�
                  Switching to SMS?  Edit TightOrderProcessor. 😬


   ✅ LOOSE COUPLING (good)
   ────────────────────────

        ┌──────────────────────────────�
        │     «interface» MessageService│
        ├──────────────────────────────┤
        │ + send(msg) : void           │
        └───────┬───────────────┬──────┘
                │               │
        ──impl──┤               ├──impl──
                ▼               ▼
      ┌─────────────────┐   ┌─────────────────┐
      │  EmailService   │   │    SmsService   │
      │   "via email"   │   │   "via SMS"     │
      └─────────────────┘   └─────────────────┘
                ▲               ▲
                │               │  INJECTED at runtime
                │               │
        ┌───────┴───────────────┴──────┐
        │      LooseOrderProcessor     │
        ├──────────────────────────────�
        │ - service : MessageService   │   ◄── accepts ANY implementation
        ├──────────────────────────────┤
        │ + LooseOrderProcessor(svc)   │   (constructor injection)
        │ + placeOrder(item)           │   ──►  service.send(...)
        └──────────────────────────────┘
        Adding Slack?  Just write SlackService implements MessageService. ✨
```

### Targets
- **Low coupling**: classes don't know each other's internals; they talk through interfaces.
- **High cohesion**: each class does ONE thing well (single responsibility).
