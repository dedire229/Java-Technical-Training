// ============================================================
// 17 - COUPLING & COHESION
// ============================================================
// COUPLING — how much one class KNOWS about another.
//   LOOSE coupling = good (classes independent; easy to swap)
//
// COHESION — how focused a single class's responsibilities are.
//   HIGH cohesion = good (a class does ONE thing well)
//
// "Strive for loosely coupled, highly cohesive designs."
//                                  — Head First Java
// ============================================================

// ----- Tightly coupled (BAD) -----
// Directly hardcoded to a specific email provider.
class TightOrderProcessor {
    private GmailService gmail = new GmailService();  // direct dependency

    public void placeOrder(String item) {
        gmail.send("Order placed: " + item);   // locked into Gmail
    }
}

class GmailService {
    public void send(String msg) {
        System.out.println("[Gmail] " + msg);
    }
}

// ----- Loosely coupled (GOOD) -----
// Depends on an INTERFACE — any provider can be plugged in.
interface MessageService {
    void send(String msg);
}

class EmailService implements MessageService {
    public void send(String msg) { System.out.println("[Email] " + msg); }
}
class SmsService implements MessageService {
    public void send(String msg) { System.out.println("[SMS]   " + msg); }
}

class LooseOrderProcessor {
    private MessageService service;
    public LooseOrderProcessor(MessageService service) {
        this.service = service;          // injected — swap any time
    }
    public void placeOrder(String item) {
        service.send("Order placed: " + item);
    }
}

class CouplingAndCohesionDemo {
    public static void main(String[] args) {
        System.out.println("--- Tight coupling (locked to Gmail) ---");
        new TightOrderProcessor().placeOrder("Book");

        System.out.println("\n--- Loose coupling (swap providers easily) ---");
        new LooseOrderProcessor(new EmailService()).placeOrder("Book");
        new LooseOrderProcessor(new SmsService()).placeOrder("Pen");
    }
}
