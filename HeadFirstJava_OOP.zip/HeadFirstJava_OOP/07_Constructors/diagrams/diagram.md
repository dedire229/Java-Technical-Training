# 07 — Constructors — Class Diagram

## Concept
Constructors run when you say `new`. They make sure the object starts life in a **valid state**.

## Diagram

```
┌──────────────────────────────────────────────────────────┐
│                          Coffee                          │
├──────────────────────────────────────────────────────────┤
│ - size         : String                                 │
│ - hasMilk      : boolean                                │
│ - sugarPackets : int                                    │
├──────────────────────────────────────────────────────────┤
│ + Coffee()                                  // no-arg   │
│ + Coffee(size: String, hasMilk: boolean)    // 2-arg    │
│ + Coffee(size, hasMilk, sugarPackets)       // 3-arg    │
├──────────────────────────────────────────────────────────┤
│ + describe() : String                                   │
└──────────────────────────────────────────────────────────┘

                       this()  chaining
                       ◄─────────────
       �─────────────────────────┐
       │  Coffee()               │ ───► calls Coffee(size, hasMilk, sugarPackets)
       └─────────────────────────┘
       ┌─────────────────────────┐
       │  Coffee(size, hasMilk)  │ ───► calls Coffee(size, hasMilk, sugarPackets)
       └─────────────────────────┘
       ┌─────────────────────────────────────────┐
       │  Coffee(size, hasMilk, sugarPackets)    │ ◄── the "real" one with body
       └─────────────────────────────────────────┘
```

### Rules of thumb
| Rule | Why |
|---|---|
| Same name as class | Compiler recognizes it as a constructor |
| No return type | Even `void` is forbidden |
| Multiple constructors | Different parameter lists = overloading |
| Default only if you write NO constructor | Otherwise: compile error if you try `new Coffee()` |
| Use `this(...)` | First statement of a constructor to chain |
