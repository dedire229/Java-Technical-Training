// ============================================================
// 07 - CONSTRUCTORS
// ============================================================
// "Constructors run when you say `new`. They make sure the
//  object starts life in a valid state."
//                                  — Head First Java
//
// - Same name as class, no return type
// - Default constructor (no-arg) is provided only if you write NO constructors
// - Use `this()` to chain to another constructor
// ============================================================

class Coffee {
    private String size;
    private boolean hasMilk;
    private int sugarPackets;

    // No-arg constructor (default)
    public Coffee() {
        this("Medium", false, 0);   // constructor chaining
    }

    // Two-arg constructor
    public Coffee(String size, boolean hasMilk) {
        this(size, hasMilk, 0);
    }

    // Three-arg constructor — the "real" one
    public Coffee(String size, boolean hasMilk, int sugarPackets) {
        this.size         = size;
        this.hasMilk      = hasMilk;
        this.sugarPackets = sugarPackets;
        System.out.println("Making a " + this.describe());
    }

    public String describe() {
        return size + " coffee" +
               (hasMilk ? " with milk" : " no milk") +
               ", " + sugarPackets + " sugar(s).";
    }

    public static void main(String[] args) {
        Coffee a = new Coffee();                              // uses no-arg
        Coffee b = new Coffee("Large", true);                 // uses 2-arg
        Coffee c = new Coffee("Small", false, 2);             // uses 3-arg

        System.out.println("\nOrder summary:");
        System.out.println("  A: " + a.describe());
        System.out.println("  B: " + b.describe());
        System.out.println("  C: " + c.describe());
    }
}
