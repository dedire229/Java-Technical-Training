# 12 — Packages — Class Diagram

## Concept
Packages = folders that group related classes. They give you:
- **Namespace** (avoid name collisions)
- **Access control** (package-private = default modifier)
- **Organization & discoverability**

## Diagram

```
   ┌─── package ─────────────────────┐    ┌─── package ─────────────────────┐
   │  com.headfirst.util             │    │  com.headfirst.text             │
   │                                 │    │                                 │
   │   ┌───────────────────────────┐ │    │   ┌───────────────────────────┐ │
   │   │       MathUtil            │ │    │   │       TextUtil            │ │
   │   ├───────────────────────────┤ │    │   ├───────────────────────────┤ │
   │   │ + square(x: int)          │ │    │   │ + shout(s): String        │ │
   │   │ + cube(x: int)            │ │    │   │ + whisper(s): String      │ │
   │   └───────────────────────────┘ │    │   └───────────────────────────┘ │
   └─────────────────────────────────�    └─────────────────────────────────┘

                       ▲                            ▲
                       │                            │
                       │        ┌─────────────┐     │
                       └────────│  MyClass    │─────┘
                       import   └─────────────┘ import
                                (in another package)
```

### Mechanics
```java
package com.headfirst.util;          // file lives under src/com/headfirst/util/

import com.headfirst.util.MathUtil;  // full path
import static com.headfirst.util.MathUtil.square;  // static import (use directly)
```

### Access by package
| Modifier    | Same class | Same package | Subclass | Anywhere |
|---|---|---|---|---|
| `public`    | ✔ | ✔ | ✔ | ✔ |
| `protected` | ✔ | ✔ | ✔ | ✘ |
| (default)   | ✔ | ✔ | ✘ | ✘ |
| `private`   | ✔ | ✘ | ✘ | ✘ |
