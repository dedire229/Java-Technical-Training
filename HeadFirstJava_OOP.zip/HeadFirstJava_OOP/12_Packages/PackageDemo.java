// ============================================================
// 12 - PACKAGES
// ============================================================
// Packages = folders that group related classes together.
// They provide:
//   - namespace (avoid name collisions)
//   - access control (package-private = default)
//   - organization / discoverability
//
// Use `import` to bring classes from other packages into scope.
//                                  — Head First Java
//
// NOTE: To make this file truly package-based, you'd split it
// across folders with `package` declarations. This single-file
// version shows the concepts & syntax.
// ============================================================

// Simulate: package com.headfirst.util;
class MathUtil {
    public static int square(int x) { return x * x; }
    public static int cube(int x)   { return x * x * x; }
}

// Simulate: package com.headfirst.text;
class TextUtil {
    public static String shout(String s) { return s.toUpperCase() + "!"; }
    public static String whisper(String s) { return "(" + s.toLowerCase() + ")"; }
}

class PackageDemo {
    public static void main(String[] args) {
        // In a real project you'd write:
        //   import com.headfirst.util.MathUtil;
        //   import static com.headfirst.util.MathUtil.square;
        // For this demo the classes share the default package.

        System.out.println("MathUtil.square(5)  = " + MathUtil.square(5));
        System.out.println("MathUtil.cube(3)    = " + MathUtil.cube(3));
        System.out.println("TextUtil.shout()    = " + TextUtil.shout("hello"));
        System.out.println("TextUtil.whisper()  = " + TextUtil.whisper("SECRET"));
    }
}
