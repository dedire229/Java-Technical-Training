// ============================================================
// 06 - INTERFACES
// ============================================================
// "An interface is a 100% abstract class. It defines a CONTRACT
//  that any class implementing it must fulfill."
//                                  — Head First Java

// "A Java interface can only contain method signatures and fields. 
// The interface can be used to achieve polymorphism."
//                                   - Hackerrank
//
// Java 8+ allows default & static methods in interfaces.
// A class can implement MULTIPLE interfaces (Java's workaround
// for not supporting multiple inheritance of classes).
// ============================================================

interface Flyable {
    void fly();  // implicitly public abstract
    default void land() {  // default method (Java 8+)
        System.out.println("Landing safely...");
    }
}

interface Swimmable {
    void swim();
}

// A class can implement BOTH — multiple inheritance of type
class Duck implements Flyable, Swimmable {
    private String name;

    public Duck(String name) { this.name = name; }

    @Override
    public void fly() {
        System.out.println(name + " the duck flaps wings and flies!");
    }

    @Override
    public void swim() {
        System.out.println(name + " paddles across the pond.");
    }
}

class Airplane implements Flyable {
    @Override
    public void fly() {
        System.out.println("Jet engines roar — airplane takes off!");
    }
}

class InterfaceDemo {
    public static void main(String[] args) {
        Duck donald = new Duck("Donald");
        donald.fly();
        donald.swim();
        donald.land();   // inherited default method

        System.out.println();

        Flyable jet = new Airplane();
        jet.fly();
        jet.land();

        // Polymorphism through interface type
        Flyable[] flyingThings = { new Duck("Daffy"), new Airplane() };
        for (Flyable f : flyingThings) {
            f.fly();
        }
    }
}
