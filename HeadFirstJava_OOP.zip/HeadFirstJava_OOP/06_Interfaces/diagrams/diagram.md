# 06 — Interfaces — Class Diagram

## Concept
A **100% abstract contract**. Classes that `implements` an interface promise to provide its methods. A class can implement **multiple interfaces**.

## Diagram

```
  «interface»               «interface»
   Flyable                   Swimmable
  ┌───────────────┐         ┌───────────────┐
  │ + fly()       │         │ + swim()      │
  │ + land() (def)│         └───────┬───────┘
  └───────┬───────┘                 │
          │                         │
          │                         │ implements BOTH
          │            ┌────────────┴────────────┐
          └────────────┤          Duck           │
                       ├─────────────────────────┤
                       │ - name : String         │
                       ├─────────────────────────┤
                       │ + fly()                 │
                       │ + swim()                │
                       └─────────────────────────┘

                                ▲
                                │ implements (only one)
                                │
                       ┌─────────────────────────┐
                       │        Airplane         │
                       ├─────────────────────────┤
                       │ + fly()                 │
                       └─────────────────────────┘
```

### Interface vs. Abstract class

|  | Interface | Abstract class |
|---|---|---|
| Methods | abstract + default + static | abstract + concrete |
| State (fields) | only `static final` constants | any fields |
| Inheritance | many interfaces | one class only |
| Purpose | "what you can do" (capability) | "what you are" (identity) |

### Demo insight
```java
Flyable[] flyingThings = { new Duck("Daffy"), new Airplane() };
for (Flyable f : flyingThings) f.fly();   // one call → different behavior
```
