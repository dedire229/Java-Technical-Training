# 01 — Classes & Objects — Class Diagram

## Concept
A class is a **blueprint**; an object is a **thing built from the blueprint**.

## Diagram

```
�──────────────────────────────────────────────┐
│                  Dog                         │   ◄── class (blueprint)
├──────────────────────────────────────────────┤
│ - name  : String                             │
│ - age   : int                                │
│ - breed : String                             │
├──────────────────────────────────────────────┤
│ + bark()                  : void             │
│ + fetch(item: String)     : void             │
│ + introduce()             : void             │
│ + main(String[])          : void (driver)    │
└────────────────┬─────────────────────────────┘
                 │  instantiated as
                 │       │
                 │       ├────────────►  buddy : Dog   (object #1)
                 │       │                  name="Buddy",  age=3, breed="Labrador"
                 │       │
                 │       └────────────►  rex   : Dog   (object #2)
                 │                          name="Rex",    age=5, breed="German Shepherd"
                 │
                 ▼
       ONE BLUEPRINT  ──►  MANY OBJECTS
```

### Key takeaways
- **State** (instance variables) is per-object — `buddy.age` ≠ `rex.age`.
- **Behavior** (methods) is shared — same `bark()` code runs for every `Dog`.
- One source file can contain many classes, but only one `public` class (matching the filename).
