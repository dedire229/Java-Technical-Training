// ============================================================
// 01 - CLASSES & OBJECTS
// ============================================================
// Head First Java says: A class is a blueprint; an object is the
// thing you make FROM that blueprint. One blueprint → many objects.
//
// Real-world analogy: A "Dog" class is the *idea* of a dog.
// "Buddy" and "Rex" are *actual* dogs (objects/instances).
// ============================================================

public class Dog {
    // ---- Instance variables (the STATE of each dog) ----
    String name;
    int age;
    String breed;

    // ---- Methods (the BEHAVIOR) ----
    public void bark() {
        System.out.println(name + " says: Woof!");
    }

    public void fetch(String item) {
        System.out.println(name + " fetches the " + item + "!");
    }

    public void introduce() {
        System.out.println("Hi, I'm " + name +
                           ", a " + breed +
                           ", and I'm " + age + " years old.");
    }

    // ---- Main: drive the example ----
    public static void main(String[] args) {
        // Each `new Dog()` creates a separate OBJECT (instance)
        Dog buddy = new Dog();
        buddy.name  = "Buddy";
        buddy.age   = 3;
        buddy.breed = "Labrador";

        Dog rex = new Dog();
        rex.name  = "Rex";
        rex.age   = 5;
        rex.breed = "German Shepherd";

        buddy.introduce();
        buddy.bark();

        rex.introduce();
        rex.fetch("ball");
    }
}
