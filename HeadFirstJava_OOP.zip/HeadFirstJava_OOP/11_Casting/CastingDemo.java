// ============================================================
// 11 - CASTING
// ============================================================
// Two flavors:
// 1) Primitive casting — widening (auto) vs narrowing (explicit)
// 2) Object reference casting — upcasting (auto) vs downcasting (risky!)
//
// Always check with `instanceof` before downcasting.
//                                  — Head First Java
// ============================================================

class Animal2 {
    public void eat() { System.out.println("Animal eats"); }
}

class Dog2 extends Animal2 {
    @Override
    public void eat() { System.out.println("Dog eats kibble"); }
    public void fetch() { System.out.println("Dog fetches!"); }
}

class Cat2 extends Animal2 {
    @Override
    public void eat() { System.out.println("Cat eats fish"); }
    public void purr() { System.out.println("Cat purrs..."); }
}

class CastingDemo {
    public static void main(String[] args) {
        // ---- Primitive widening (automatic, safe) ----
        int    i = 42;
        double d = i;          // int → double
        System.out.println("Widening: int " + i + " → double " + d);

        // ---- Primitive narrowing (explicit, may lose data) ----
        double pi = 3.99;
        int truncated = (int) pi;   // chops off decimal
        System.out.println("Narrowing: double " + pi + " → int " + truncated);

        System.out.println("\n--- Object casting ---");

        // ---- Upcasting (automatic, safe) ----
        Dog2 d2 = new Dog2();
        Animal2 a2 = d2;          // Dog IS-A Animal — always safe
        a2.eat();                 // calls Dog's overridden version

        // ---- Downcasting (explicit, RISKY) ----
        Animal2 maybeDog = new Dog2();
        if (maybeDog instanceof Dog2) {
            Dog2 confirmedDog = (Dog2) maybeDog;
            confirmedDog.fetch();
        }

        // ---- Risky downcast caught safely ----
        Animal2 maybeCat = new Cat2();
        if (maybeCat instanceof Dog2) {
            Dog2 wrongCast = (Dog2) maybeCat;  // never runs
            wrongCast.fetch();
        } else {
            System.out.println("Nope, that animal isn't a Dog.");
        }
    }
}
