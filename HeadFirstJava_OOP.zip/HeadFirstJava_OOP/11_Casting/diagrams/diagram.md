# 11 — Casting — Class Diagram

## Concept
Converting one reference (or value) to another. Two flavors:
- **Primitive** — widening (auto, safe) vs narrowing (explicit, may lose data).
- **Object reference** — upcasting (auto, safe) vs downcasting (explicit, risky → use `instanceof`).

## Diagram

```
   PRIMITIVE WIDENING (auto, safe)              PRIMITIVE NARROWING (explicit)
   ──────────────────────────────               ───────────────────────────────
        int  i  = 42;                                 double pi = 3.99;
        double d = i;                                 int truncated = (int) pi;  // 3


   OBJECT UPCASTING (auto, safe)                OBJECT DOWNCASTING (explicit, risky)
   ────────────────────────────────              ──────────────────────────────
        Dog2 d = new Dog2();                          Animal2 a = new Dog2();
        Animal2 a = d;          // OK                   Dog2 d = (Dog2) a;        // OK if really a Dog
                                                      if (a instanceof Dog2) { ... }


                       ┌─────────────────────────────┐
                       │           Animal2           │   ◄── parent (reference type)
                       ├─────────────────────────────┤
                       │  + eat() : void             │
                       └──────────┬──────────┬───────┘
                                  │          │
                       ─extends────┤          ├────extends────
                                  │          │
                                  ▼          ▼
                       ┌─────────────────┐  ┌─────────────────┐
                       │      Dog2       │  │      Cat2       │
                       ├─────────────────�  ├─────────────────┤
                       │ + fetch()       │  │ + purr()        │
                       └─────────────────┘  └─────────────────┘


         Animal2 a = new Cat2();
         if (a instanceof Dog2) {              // false → safe skip
             Dog2 d = (Dog2) a;
             d.fetch();
         } else {
             System.out.println("Not a Dog.");
         }
```

### Golden rule
**Always check `instanceof` BEFORE downcasting.** Without it, a `ClassCastException` waits at runtime.
