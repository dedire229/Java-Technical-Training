// ============================================================
// 03 - POLYMORPHISM
// ============================================================
// "Poly" = many, "morph" = forms. The SAME method call behaves
// DIFFERENTLY based on the actual OBJECT type at runtime.
//
// In Head First Java: The reference type can be the parent,
// but the object can be a child. Java figures out the right
// method at runtime (dynamic dispatch).
// ============================================================

class Vehicle {
    public void start() {
        System.out.println("Vehicle is starting...");
    }
}

class Car extends Vehicle {
    @Override
    public void start() {
        System.out.println("Car: Turn key, engine roars to life!");
    }
}

class ElectricCar extends Vehicle {
    @Override
    public void start() {
        System.out.println("ElectricCar: Press button, silent hum begins.");
    }
}

class Motorcycle extends Vehicle {
    @Override
    public void start() {
        System.out.println("Motorcycle: Kick start, vroom!");
    }
}

class PolymorphismDemo {
    public static void main(String[] args) {
        // Reference type is Vehicle, but object type varies.
        // The SAME call `v.start()` produces different behavior.
        Vehicle v;

        v = new Car();
        v.start();

        v = new ElectricCar();
        v.start();

        v = new Motorcycle();
        v.start();

        // Polymorphic array — every shape fits, each behaves its own way
        System.out.println("\n--- Polymorphic Array ---");
        Vehicle[] garage = { new Car(), new ElectricCar(), new Motorcycle() };
        for (Vehicle veh : garage) {
            veh.start();
        }
    }
}
