# 03 — Polymorphism — Class Diagram

## Concept
**One interface, many implementations.** The same method call behaves differently based on the actual object type at runtime.

## Diagram

```
                       ┌──────────────────────────────────┐
                       │             Vehicle              │   ◄── reference type
                       ├──────────────────────────────────┤
                       │  + start() : void                │   (overridden in each child)
                       └────────────┬──────────┬──────────┘
                                    │          │
                       ────extends──┤          ├──extends────
                                    │          │
                                    ▼          ▼
                       ┌───────────────────┐  ┌───────────────────────┐
                       │       Car         │  │     ElectricCar       │
                       ├───────────────────┤  ├───────────────────────┤
                       │  + start()        │  │  + start()            │
                       │   "engine roars!" │  │   "silent hum begins" │
                       └───────────────────┘  └───────────────────────┘
                                    ▲          ▲
                                    │          │
                       ┌───────────────────┐
                       │    Motorcycle     │
                       ├───────────────────┤
                       │  + start()        │
                       │   "kick start!"   │
                       └───────────────────┘


Runtime dispatch (dynamic dispatch):

   Vehicle v;            // reference type: Vehicle
   v = new Car();       v.start();  →  "engine roars!"
   v = new ElectricCar(); v.start(); → "silent hum begins"
   v = new Motorcycle(); v.start(); → "kick start!"
```

### Why it's powerful
- New vehicle types can be added **without changing the calling code**.
- The caller treats everything as a `Vehicle` and lets the JVM pick the right `start()` at runtime.
