// ============================================================
// 02 - INHERITANCE
// ============================================================
// "When you inherit, you get everything from the parent.
// You can add new stuff, or change (override) the inherited stuff."
//                                  — Head First Java
//
// Java uses the `extends` keyword. Single inheritance only
// (a class can extend ONE parent).
//
// Example: Dog IS-A Animal. Cat IS-A Animal.
// ============================================================

// --- Parent (super) class ---
class Animal {
    String name;

    public void eat() {
        System.out.println(name + " is eating.");
    }

    public void sleep() {
        System.out.println(name + " is sleeping. Zzz...");
    }
}

// Child class inherits from Animal 
class Dog extends Animal {
    // Dog has its OWN method in addition to inherited ones
    public void bark() {
        System.out.println(name + " says: Woof!");
    }
}

class Cat extends Animal {
    public void meow() {
        System.out.println(name + " says: Meow!");
    }
}

// Driver Class
class InheritanceDemo {
    public static void main(String[] args) {
        Dog d = new Dog();
        d.name = "Buddy";
        d.eat();   // INHERITED from Animal
        d.sleep(); // INHERITED from Animal
        d.bark();  // Dog's own method

        System.out.println();

        Cat c = new Cat();
        c.name = "Whiskers";
        c.eat();
        c.meow();

        System.out.println();
        System.out.println("Dog IS-A Animal? " + (d instanceof Animal)); // true
    }
}
