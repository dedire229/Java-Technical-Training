# 02 — Inheritance — Class Diagram

## Concept
Use `extends` to build an **IS-A** hierarchy. Subclass inherits all accessible state & behavior of the parent and can add or override.

## Diagram

```
                ┌──────────────────────────────────┐
                │            Animal                │   ◄── superclass
                ├──────────────────────────────────┤
                │  # name : String                 │
                ├──────────────────────────────────┤
                │  + eat()   : void                │
                │  + sleep() : void                │
                └────────────┬──────────┬──────────┘
                             │          │
                ──────extends──────    ──────extends──────
                       │                       │
                       ▼                       ▼
        ┌───────────────────────────┐   ┌───────────────────────────┐
        │            Dog            │   │            Cat            │
        ├───────────────────────────┤   ├───────────────────────────┤
        ├───────────────────────────┤   ├───────────────────────────┤
        │  + bark() : void          │   │  + meow() : void          │
        └───────────────────────────┘   └───────────────────────────┘
```

### Key relationships
| Relationship | UML arrow | Java keyword |
|---|---|---|
| `Dog` IS-A `Animal` | hollow triangle ──▷ | `extends` |

### Demo flow
```
Animal a = new Dog();   // upcast — legal
a.eat();                // calls inherited Animal method
a.sleep();              // calls inherited Animal method
a.bark();               // COMPILE ERROR — bark() not on Animal reference
((Dog) a).bark();       // downcast — now legal
```
