# 10 — Overloading & Overriding — Class Diagram

## Concept
- **Overloading** (compile-time): same method NAME, different PARAMETER LIST in the same class.
- **Overriding** (run-time): subclass provides a NEW implementation with the SAME signature.

## Diagram

```
┌──────────────────────────────────────────────────────────┐
│                       Calculator                          │
├──────────────────────────────────────────────────────────┤
│ + add(int a, int b)             : int                     │  ◄── overload
│ + add(double a, double b)       : double                  │  ◄── overload
│ + add(int a, int b, int c)      : int                     │  ◄── overload
│ + add(String a, String b)       : String                  │  ◄── overload
└──────────────────────────────────────────────────────────┘
        Same name, different parameter list  =  OVERLOADING


                          ┌──────────────────────────────┐
                          │            Animal            │
                          ├──────────────────────────────�
                          │ + speak()                    │
                          │   "Animal makes a sound"     │
                          └──────────────┬───────────────┘
                                         │
                            ───extends────┤
                                         │
                                         ▼
                          ┌──────────────────────────────┐
                          │             Dog              │
                          ├──────────────────────────────┤
                          │ + speak()  «override»        │
                          │   "Dog barks"                │
                          └──────────────┬───────────────┘
                                         │
                            ───extends────┤
                                         │
                                         ▼
                          ┌──────────────────────────────┐
                          │            Puppy             │
                          ├──────────────────────────────┤
                          │ + speak()  «override»        │
                          │   super.speak()  (chain up)  │
                          │   "Puppy yips too!"          │
                          └──────────────────────────────┘

     Same signature, different implementation = OVERRIDING
```

### Compile-time vs runtime
```java
// Compile time: which add() matches the call?
calc.add(2, 3)       // → add(int, int)
calc.add(2.0, 3.0)    // → add(double, double)

// Run time: which speak() actually runs?
Animal a = new Puppy();
a.speak();    //  JVM dispatches to Puppy.speak()  (dynamic dispatch)
```
