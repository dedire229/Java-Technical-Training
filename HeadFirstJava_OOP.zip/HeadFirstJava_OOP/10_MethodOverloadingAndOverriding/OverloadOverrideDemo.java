// ============================================================
// 10 - METHOD OVERLOADING & OVERRIDING
// ============================================================
// OVERLOADING (compile-time polymorphism):
//   Same method NAME, different PARAMETERS in same class.
//
// OVERRIDING (runtime polymorphism):
//   Subclass redefines a method from its parent (same signature).
//                                  — Head First Java
// ============================================================

// ---- OVERLOADING example ----
class Calculator {
    // Same name, different parameter types/counts
    public int add(int a, int b)             { return a + b; }
    public double add(double a, double b)    { return a + b; }
    public int add(int a, int b, int c)      { return a + b + c; }
    public String add(String a, String b)    { return a + b; }  // string concat
}

// ---- OVERRIDING example ----
class Animal {
    public void speak() {
        System.out.println("Animal makes a sound");
    }
}

class Dog extends Animal {
    @Override
    public void speak() {  // exact same signature
        System.out.println("Dog barks");
    }
}

class Puppy extends Dog {
    @Override
    public void speak() {
        super.speak();    // call parent's version
        System.out.println("Puppy yips too!");
    }
}

class OverloadOverrideDemo {
    public static void main(String[] args) {
        // ---- Overloading ----
        Calculator calc = new Calculator();
        System.out.println("add(2,3)         = " + calc.add(2, 3));
        System.out.println("add(2.5,3.5)     = " + calc.add(2.5, 3.5));
        System.out.println("add(1,2,3)       = " + calc.add(1, 2, 3));
        System.out.println("add(\"Hi\",\"ya\") = " + calc.add("Hi", "ya"));

        // ---- Overriding ----
        Animal a;
        a = new Animal(); System.out.print("Animal ref → Animal: "); a.speak();
        a = new Dog();    System.out.print("Animal ref → Dog:    "); a.speak();
        a = new Puppy();  System.out.print("Animal ref → Puppy:  "); a.speak();
    }
}
