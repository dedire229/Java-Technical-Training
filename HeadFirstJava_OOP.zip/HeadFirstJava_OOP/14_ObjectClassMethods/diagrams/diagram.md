# 14 — Object Class Methods — Class Diagram

## Concept
Every Java class **implicitly extends `java.lang.Object`**, so it inherits:
- `toString()`   — string representation
- `equals()`     — logical equality
- `hashCode()`   — integer hash (must be consistent with `equals()`)
- `getClass()`   — runtime class info
- (and others like `clone()`, `notify()`, `wait()`, `finalize()`)

## Diagram

```
                     ┌──────────────────────────────────┐
                     │       java.lang.Object           │   ◄── root of all classes
                     ├──────────────────────────────────┤
                     │ + toString()         : String    │
                     │ + equals(Object)     : boolean   │
                     │ + hashCode()         : int       │
                     │ + getClass()         : Class<?>  │
                     │ + clone()            : Object    │
                     │ + finalize()         : void      │
                     │ + notify() / notifyAll()         │
                     │ + wait() / wait(long)            │
                     └────────────────▲─────────────────┘
                                      │ implicit inheritance
                     ┌────────────────┴────────────────┐
                     │              Book               │
                     ├─────────────────────────────────┤
                     │ - title  : String               │
                     │ - author : String               │
                     │ - year   : int                  │
                     ├─────────────────────────────────┤
                     │ + Book(title, author, year)     │
                     │ + getTitle() / setTitle(...)    │
                     │ + getAuthor() / setAuthor(...)  │
                     │ + getYear() / setYear(...)      │
                     ├─────────────────────────────────┤
                     │ + toString() «override»         │
                     │ + equals(Object) «override»     │
                     │ + hashCode() «override»         │
                     └─────────────────────────────────┘
```

### The equals/hashCode contract

> If `a.equals(b) == true`, then `a.hashCode() == b.hashCode()`.

Break this rule and your class misbehaves inside `HashMap`, `HashSet`, etc.

### Demonstration
```
Book b1 = new Book("Head First Java", "Kathy Sierra", 2003);
Book b2 = new Book("Head First Java", "Kathy Sierra", 2003);

b1 == b2        →  false      // different objects in memory
b1.equals(b2)   →  true       // same content
b1.hashCode()   == b2.hashCode()  →  true   // consistent with equals
```
