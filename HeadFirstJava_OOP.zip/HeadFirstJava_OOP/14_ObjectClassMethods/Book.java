// ============================================================
// 14 - OBJECT CLASS METHODS (java.lang.Object)
// ============================================================
// Every class in Java implicitly extends Object. So every object
// inherits methods like:
//   - toString()  → string representation (override for nice output)
//   - equals()    → logical equality (override for value-based equality)
//   - hashCode()  → integer hash (MUST be consistent with equals!)
//   - getClass()  → the runtime class
//                                  — Head First Java
// ============================================================

class Book {
    private String title;
    private String author;
    private int    year;

    public Book(String title, String author, int year) {
        this.title  = title;
        this.author = author;
        this.year   = year;
    }

    // -- Override toString for a friendly representation --
    @Override
    public String toString() {
        return "\"" + title + "\" by " + author + " (" + year + ")";
    }

    // -- Override equals for value-based equality --
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book)) return false;
        Book other = (Book) o;
        return this.year   == other.year
            && this.title.equals(other.title)
            && this.author.equals(other.author);
    }

    // -- Override hashCode to be consistent with equals --
    @Override
    public int hashCode() {
        int result = title.hashCode();
        result = 31 * result + author.hashCode();
        result = 31 * result + year;
        return result;
    }
}

class ObjectMethodsDemo {
    public static void main(String[] args) {
        Book b1 = new Book("Head First Java", "Kathy Sierra", 2003);
        Book b2 = new Book("Head First Java", "Kathy Sierra", 2003);
        Book b3 = new Book("Effective Java",  "Joshua Bloch",  2008);

        // Default toString vs overridden
        System.out.println("b1 (overridden toString): " + b1);

        // Default equals is reference equality (`==`)
        System.out.println("b1 == b2 : " + (b1 == b2));
        System.out.println("b1.equals(b2) : " + b1.equals(b2));   // true — same content
        System.out.println("b1.equals(b3) : " + b1.equals(b3));   // false — different book

        System.out.println("b1.hashCode() : " + b1.hashCode());
        System.out.println("b2.hashCode() : " + b2.hashCode());   // equal books → equal hash

        System.out.println("b1.getClass() : " + b1.getClass().getName());
    }
}
