# 08 — Static & Final — Class Diagram

## Concept
- **`static`** — belongs to the **class**, not instances. Shared.
- **`final`** (variable) — a constant; can't be reassigned.
- **`final`** (method) — can't be overridden.
- **`final`** (class) — can't be extended.

## Diagram

```
┌──────────────────────────────────────────────────────────┐
│                   MathConstants                          │
├──────────────────────────────────────────────────────────┤
│  + PI         : double = 3.14159...   «static final»    │
│  + MAX_SCORE  : int    = 100          «static final»    │
└──────────────────────────────────────────────────────────�
                       ▲
                       │  MathConstants.PI        ← accessed by class name
                       │  MathConstants.MAX_SCORE


┌──────────────────────────────────────────────────────────┐
│                        Player                            │
├──────────────────────────────────────────────────────────┤
│  - playerCount : int          «static»   ◄── ONE copy,   │
│  - id          : String       «final»       shared by all│
│  - name        : String                                 │
├──────────────────────────────────────────────────────────┤
│  + Player(name)                                       │
│  + getPlayerCount() : int    «static»                  │
│  + show()                                           │
└──────────────────────────────────────────────────────────┘

                      (final class — can't extend)
┌──────────────────────────────────────────────────────────┐
│  «final»  ConstantsHolder                               │
├──────────────────────────────────────────────────────────┤
│  + APP_NAME : String = "HeadFirst OOP"                  │
└──────────────────────────────────────────────────────────┘
```

### Quick visual rule

| Modifier | On what | Effect |
|---|---|---|
| `static` | field | 1 copy shared by all objects |
| `static` | method | callable via `ClassName.method()` |
| `final`  | field | constant; must be assigned once |
| `final`  | method | can't be overridden by subclasses |
| `final`  | class | can't be subclassed |
