// ============================================================
// 08 - STATIC & FINAL
// ============================================================
// static: "shared by the CLASS, not by individual instances."
//         One copy, period. Accessed via ClassName.member.
//
// final (on variable): a constant — can't be reassigned.
// final (on method):   can't be overridden by subclasses.
// final (on class):    can't be extended (no inheritance).
//                                  — Head First Java
// ============================================================

class MathConstants {
    // Class-level constants
    public static final double PI  = 3.14159265358979;
    public static final int    MAX_SCORE = 100;
}

class Player {
    private static int playerCount = 0;   // shared across all Player objects

    private final String id;             // each player gets a unique ID, can't change
    private String name;

    public Player(String name) {
        this.name = name;
        this.id   = "P" + (++playerCount); // final assigned in constructor — OK
    }

    public static int getPlayerCount() {  // static method
        return playerCount;
    }

    public void show() {
        System.out.println("Player " + id + ": " + name);
    }
}

// final class — can't be subclassed
final class ConstantsHolder {
    public static final String APP_NAME = "HeadFirst OOP";
}

class StaticAndFinalDemo {
    public static void main(String[] args) {
        // Access static constants via class name
        System.out.println("PI = " + MathConstants.PI);
        System.out.println("MAX_SCORE = " + MathConstants.MAX_SCORE);

        // No Player objects yet
        System.out.println("\nPlayers before: " + Player.getPlayerCount());

        Player p1 = new Player("Alice");
        Player p2 = new Player("Bob");
        Player p3 = new Player("Charlie");

        p1.show();
        p2.show();
        p3.show();

        // Class-level counter incremented automatically
        System.out.println("\nPlayers now: " + Player.getPlayerCount());

        // ConstantsHolder is final — cannot be extended:
        // class Sub extends ConstantsHolder {} // <-- compile error
    }
}
