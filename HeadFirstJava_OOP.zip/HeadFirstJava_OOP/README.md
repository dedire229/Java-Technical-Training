# Head First Java - OOP Concepts

A comprehensive collection of Object-Oriented Programming (OOP) concepts with practical examples, inspired by **Head First Java** by Kathy Sierra & Bert Bates.

## 📁 Folder Structure

| # | Topic | Description |
|---|-------|-------------|
| 01 | Classes & Objects | Blueprint and instance fundamentals |
| 02 | Inheritance | Parent-child class relationships |
| 03 | Polymorphism | One interface, many implementations |
| 04 | Abstraction | Hiding complexity, exposing essentials |
| 05 | Encapsulation | Protecting internal state |
| 06 | Interfaces | Contracts and multiple inheritance |
| 07 | Constructors | Object initialization |
| 08 | Static & Final | Class-level members and constants |
| 09 | Abstract Classes | Partial implementation templates |
| 10 | Method Overloading & Overriding | Compile-time vs runtime polymorphism |
| 11 | Casting | Object reference conversions |
| 12 | Packages | Code organization & namespaces |
| 13 | Access Modifiers | public, private, protected, default |
| 14 | Object Class Methods | equals(), hashCode(), toString() |
| 15 | Design Patterns | Common OOP solutions (Strategy, Observer, Decorator) |
| 16 | Composition | "Has-a" relationships |
| 17 | Coupling & Cohesion | Designing for change |
| 18 | Real World Examples | Putting it all together |

## The 4 Pillars of OOP

1. **Encapsulation** — Bundle data + behavior; hide the details
2. **Inheritance** — Reuse code through parent-child hierarchies
3. **Polymorphism** — Same message, different behavior
4. **Abstraction** — Focus on *what*, not *how*

## How to Use

Each folder contains `.java` files with:
- **Concept explanation** at the top as comments
- **Head First Java style** simple, illustrative examples
- **Main class** with a runnable `main` method

Compile and run any example:
```bash
javac FolderName/*.java
java FolderName.MainClassName
```

## 📖 Inspired By

- **Head First Java** (3rd Edition) — Kathy Sierra & Bert Bates
- Uses the book's signature teaching style: simple analogies, real-world scenarios, and code that "clicks"

Happy coding! ☕
