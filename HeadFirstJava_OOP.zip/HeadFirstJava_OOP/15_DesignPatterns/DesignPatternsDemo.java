// ============================================================
// 15 - DESIGN PATTERNS
// ============================================================
// Head First Design Patterns is the sequel book. The patterns
// are deeply rooted in OOP principles. Below are 3 quick
// demonstrations:
//   1. Strategy  — pick algorithm at runtime
//   2. Observer  — broadcast changes to subscribers
//   3. Decorator — wrap objects to add behavior
// ============================================================

// ----- 1) STRATEGY -----
interface FlyBehavior { void fly(); }
class FlyWithWings  implements FlyBehavior {
    public void fly() { System.out.println("Flying with wings!"); }
}
class FlyNoWay     implements FlyBehavior {
    public void fly() { System.out.println("Can't fly — sitting still."); }
}

class Duck {
    private FlyBehavior flyBehavior;
    public Duck(FlyBehavior fb) { this.flyBehavior = fb; }
    public void setFlyBehavior(FlyBehavior fb) { this.flyBehavior = fb; }
    public void performFly() { flyBehavior.fly(); }
}

// ----- 2) OBSERVER -----
import java.util.ArrayList;
import java.util.List;

interface Observer { void update(String msg); }

class NewsAgency {
    private List<Observer> channels = new ArrayList<>();
    public void subscribe(Observer o)   { channels.add(o); }
    public void unsubscribe(Observer o) { channels.remove(o); }
    public void publish(String news) {
        System.out.println("Publishing: " + news);
        for (Observer o : channels) o.update(news);
    }
}

class NewsChannel implements Observer {
    private String name;
    public NewsChannel(String name) { this.name = name; }
    public void update(String msg) {
        System.out.println("  " + name + " received: " + msg);
    }
}

// ----- 3) DECORATOR -----
interface Coffee2 {
    String getDescription();
    double cost();
}
class SimpleCoffee implements Coffee2 {
    public String getDescription() { return "Coffee"; }
    public double cost()           { return 2.00; }
}
abstract class CoffeeDecorator implements Coffee2 {
    protected Coffee2 wrapped;
    public CoffeeDecorator(Coffee2 c) { this.wrapped = c; }
    public String getDescription()    { return wrapped.getDescription(); }
    public double cost()              { return wrapped.cost(); }
}
class MilkDecorator extends CoffeeDecorator {
    public MilkDecorator(Coffee2 c)   { super(c); }
    public String getDescription()    { return wrapped.getDescription() + ", Milk"; }
    public double cost()              { return wrapped.cost() + 0.50; }
}
class SugarDecorator extends CoffeeDecorator {
    public SugarDecorator(Coffee2 c)  { super(c); }
    public String getDescription()    { return wrapped.getDescription() + ", Sugar"; }
    public double cost()              { return wrapped.cost() + 0.25; }
}

class DesignPatternsDemo {
    public static void main(String[] args) {
        System.out.println("=== STRATEGY ===");
        Duck rubber = new Duck(new FlyNoWay());
        rubber.performFly();
        rubber.setFlyBehavior(new FlyWithWings());
        rubber.performFly();

        System.out.println("\n=== OBSERVER ===");
        NewsAgency agency = new NewsAgency();
        agency.subscribe(new NewsChannel("Channel A"));
        agency.subscribe(new NewsChannel("Channel B"));
        agency.publish("Head First Java OOP examples are ready!");

        System.out.println("\n=== DECORATOR ===");
        Coffee2 myCoffee = new SugarDecorator(new MilkDecorator(new SimpleCoffee()));
        System.out.println("Order: " + myCoffee.getDescription());
        System.out.println("Total: $" + myCoffee.cost());
    }
}
