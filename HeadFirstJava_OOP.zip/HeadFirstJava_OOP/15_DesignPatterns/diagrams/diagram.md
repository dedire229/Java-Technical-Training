# 15 — Design Patterns — Class Diagrams

Head First Design Patterns is the follow-up book. These patterns are deeply rooted in OOP.

## 1. Strategy — pick algorithm at runtime

```
         ┌─────────────────────────┐
         │   «interface» FlyBehavior│
         ├─────────────────────────┤
         │ + fly() : void          │
         └───────┬────────�────────┘
                 │        │
       ──impl────┤        ├────impl────
                 │        │
                 ▼        ▼
         ┌────────────────┐    ┌────────────────�
         │  FlyWithWings  │    │    FlyNoWay    │
         ├────────────────┤    ├────────────────┤
         │ + fly()        │    │ + fly()        │
         │   "wings!"    │    │   "no flying" │
         └────────────────┘    └────────────────┘

                 ┌─────────────────────┐
                 │        Duck         │
                 ├─────────────────────┤
                 │ - flyBehavior       │  ◄── composition
                 ├─────────────────────┤
                 │ + performFly()      │  ──► flyBehavior.fly()
                 │ + setFlyBehavior()  │
                 └─────────────────────┘
```

## 2. Observer — broadcast changes

```
                ┌─────────────────────┐         ┌──────────────────────┐
                │    «interface»      │         │      NewsAgency      │
                │     Observer        │         ├──────────────────────┤
                ├─────────────────────┤         │ - channels : List    │
                │ + update(msg) : void│         │                      │
                └──────────┬──────────┘         │ + subscribe(o)       │
                           │                    │ + unsubscribe(o)     │
                ──implements─┤                   │ + publish(news)      │
                           │                    └──────────┬───────────┘
                           ▼                               │ notify all
                  ┌─────────────────┐                     │
                  │   NewsChannel   │ ◄───────────────────┘
                  ├─────────────────┤
                  │ - name : String │
                  │ + update(msg)   │
                  └─────────────────┘
```

## 3. Decorator — wrap to add behavior

```
            ┌───────────────────────┐
            │   «interface» Coffee2 │
            ├───────────────────────┤
            │ + getDescription()    │
            │ + cost()              │
            └────┬─────────────┬─────┘
                 │             │
                 │     ┌───────┴──────────┐
                 │     │  «abstract»      │
                 │     │ CoffeeDecorator  │
                 │     ├──────────────────┤
                 │     │ - wrapped        │
                 │     └──────┬───────────┘
                 │            │
       ──impl─────┤            │
                 │            │
                 ▼            ▼
         ┌──────────────┐  ┌──────────────────┐
         │ SimpleCoffee │  │  MilkDecorator   │ ── wraps ──► Coffee2
         ├──────────────�  ├──────────────────┤
         │ cost() = 2.00│  │ cost() + 0.50    │
         └──────────────┘  └──────────────────┘
                                  │
                                  ▼
                          ┌──────────────────┐
                          │ SugarDecorator   │ ── wraps ──► Coffee2
                          ├──────────────────┤
                          │ cost() + 0.25    │
                          └──────────────────┘
```

### Order of construction
```java
Coffee2 c = new SugarDecorator(
                new MilkDecorator(
                    new SimpleCoffee()));
// Description: "Coffee, Milk, Sugar"
// Total cost : 2.00 + 0.50 + 0.25
```
