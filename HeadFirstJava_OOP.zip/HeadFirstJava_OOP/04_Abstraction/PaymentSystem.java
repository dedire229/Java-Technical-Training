// ============================================================
// 04 - ABSTRACTION
// ============================================================
// "Hide the gory details. Show only the essentials."
//                                  — Head First Java
//
// In Java, abstraction is achieved via:
//   - abstract classes (partial implementation)
//   - interfaces (pure contract)
//
// This file shows the *idea* using a simple abstract class.
// (See 09_AbstractClasses and 06_Interfaces for formal examples.)
// ============================================================

// Abstract class: cannot be instantiated; forces subclasses to fill in details
abstract class Payment {
    protected double amount;

    public Payment(double amount) {
        this.amount = amount;
    }

    // Concrete method — shared by all payments
    public void printReceipt() {
        System.out.println("Receipt: payment of $" + amount);
    }

    // Abstract method — no body; each payment type MUST implement it
    public abstract void process();
}

class CreditCardPayment extends Payment {
    public CreditCardPayment(double amt) { super(amt); }

    @Override
    public void process() {
        // Hidden details (network call, encryption, etc.)
        System.out.println("Processing $" + amount + " via Credit Card.");
    }
}

class PayPalPayment extends Payment {
    public PayPalPayment(double amt) { super(amt); }

    @Override
    public void process() {
        System.out.println("Processing $" + amount + " via PayPal.");
    }
}

class AbstractionDemo {
    public static void main(String[] args) {
        // You can't say:  new Payment(100);  // <-- not allowed!
        // But you can hold any concrete subtype in a Payment reference.

        Payment p1 = new CreditCardPayment(150.00);
        Payment p2 = new PayPalPayment(89.99);

        p1.process();
        p1.printReceipt();

        System.out.println();

        p2.process();
        p2.printReceipt();

        // The CALLER doesn't care HOW each one processes — that's abstraction.
    }
}
