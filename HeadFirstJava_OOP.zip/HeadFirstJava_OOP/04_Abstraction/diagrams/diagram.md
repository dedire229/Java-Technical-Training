# 04 — Abstraction — Class Diagram

## Concept
**Hide the gory details. Show only the essentials.** Caller doesn't care HOW each thing is done, only THAT it's done.

## Diagram

```
                       ┌──────────────────────────────┐
                       │  «abstract» Payment          │  ◄── cannot be instantiated
                       ├──────────────────────────────┤
                       │  # amount : double           │
                       ├──────────────────────────────┤
                       │  + printReceipt()   : void   │   ◄── concrete, shared
                       │  + process()        : void   │   ◄── abstract (no body)
                       └──────────┬──────────┬───────┘
                                  │          │
                       ───extends──┤          ├──extends────
                                  │          │
                                  ▼          ▼
                       ┌──────────────────┐  ┌──────────────────┐
                       │ CreditCardPayment│  │   PayPalPayment  │
                       ├──────────────────┤  ├──────────────────┤
                       │ + process()      │  │ + process()      │
                       │  "via Credit..." │  │  "via PayPal..." │
                       └──────────────────┘  └──────────────────┘
```

### Abstraction levels
1. **Abstract class** — partial implementation; some methods defined, some declared.
2. **Interface** (see folder 06) — pure contract, no state.
3. **Concrete class** — everything is defined.

### Caller's view
```java
Payment p = new CreditCardPayment(150);
Payment q = new PayPalPayment(89.99);

p.process();   // ← doesn't care HOW — that's the abstraction
p.printReceipt();
```
