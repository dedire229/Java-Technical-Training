# 13 — Access Modifiers — Class Diagram

## Concept
Control **who** can see and use each member.

## Diagram

```
        Visibility scope (4 circles = the 4 modifiers)
        ─────────────────────────────────────────────────────────────────

                    ┌─────────────────────────┐
                    │       ANYWHERE          │   ◄── public
                    │   (any class, any pkg)  │
                    └────────────▲────────────┘
                                 │
                    ┌────────────┴────────────┐
                    │     SUBCLASSES          │   �── protected
                    │   (any pkg via extends) │
                    └────────────▲────────────�
                                 │
                    ┌────────────┴────────────┐
                    │    SAME PACKAGE         │   ◄── default (no keyword)
                    │                         │
                    └────────────▲────────────┘
                                 │
                    ┌────────────┴────────────┐
                    │    SAME CLASS ONLY      │   ◄── private
                    │                         │
                    └─────────────────────────┘
```

### Concrete example
```
┌──────────────────────────────────────────────────────────────┐
│                       AccessDemo                            │
├──────────────────────────────────────────────────────────────┤
│ - a : int            «private»   ──► only AccessDemo can see │
│   b : int            «default»   ──► anyone in same package │
│ # c : int            «protected» ──► same pkg + subclasses   │
│ + d : int            «public»    ──► everyone                 │
├──────────────────────────────────────────────────────────────┤
│ + show() : void                                            │
│ + main(String[])                                           │
└──────────────────────────────────────────────────────────────┘
```

### Memory aid

| Modifier    | Mnemonic |
|---|---|
| `private`   | "p" — private to me |
| (default)   | package-private — "no keyword = my package only" |
| `protected` | "p" + extended family (subclasses) |
| `public`    | "p" to the world |
