// ============================================================
// 13 - ACCESS MODIFIERS
// ============================================================
//              same class  same pkg   subclass   anywhere
// public         ✔           ✔          ✔          ✔
// protected      ✔           ✔          ✔          ✘
// default (∅)    ✔           ✔          ✘          ✘
// private        ✔           ✘          ✘          ✘
//                                  — Head First Java
// ============================================================

class AccessDemo {
    private   int a = 1;   // only AccessDemo can touch
              int b = 2;   // package-private (default)
    protected int c = 3;   // package + subclasses
    public    int d = 4;   // everyone

    public void show() {
        System.out.println("a (private)   = " + a);
        System.out.println("b (default)   = " + b);
        System.out.println("c (protected) = " + c);
        System.out.println("d (public)    = " + d);
    }

    public static void main(String[] args) {
        AccessDemo obj = new AccessDemo();
        obj.show();
        // obj.a = 99; // ✘ compile error outside AccessDemo
        obj.b = 20;
        obj.c = 30;
        obj.d = 40;
        System.out.println("\nAfter modifying visible ones:");
        obj.show();
    }
}
