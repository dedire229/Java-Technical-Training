# 16 — Composition — Class Diagram

## Concept
**"Favor composition over inheritance."** A `Car` HAS-A `Engine`. HAS-A relationships let you swap parts at runtime and avoid fragile parent-class coupling.

## Diagram

```
                ┌───────────────────────┐
                │         Engine        │   ◄── swappable component
                ├───────────────────────┤
                │ - type       : String │
                │ - horsepower : int    │
                ├───────────────────────┤
                │ + start()             │
                │ + getType()           │
                │ + getHorsepower()     │
                └───────────────────────┘
                            ▲
                            │  HAS-A  (1 ──── 1)
                            │
                ┌───────────┴───────────────────┐
                │            Car                │
                ├───────────────────────────────┤
                │ - engine : Engine             │  ◄── composition
                │ - gps    : GPS                │  ◄── composition
                │ - model  : String             │
                ├───────────────────────────────┤
                │ + drive(address)              │
                │ + upgradeEngine(newEngine)    │  �── swap parts at runtime!
                └───────────────────────────────┘
                            ▲
                            │
                ┌───────────┴───────────┐
                │         GPS           │   ◄── another swappable component
                ├───────────────────────┤
                │ - brand : String      │
                ├───────────────────────┤
                │ + navigate(address)   │
                └───────────────────────┘
```

### Inheritance vs Composition

|  | Inheritance (IS-A) | Composition (HAS-A) |
|---|---|---|
| Coupling | tight (parent change breaks children) | loose (parts swappable) |
| Flexibility | compile-time fixed | runtime swappable |
| Reuse | limited (one parent only) | multiple parts |
| Risk | "fragile base class" | low |

### Demo
```java
Car myCar = new Car("Sedan X", new Engine("V6", 300), new GPS("TomTom"));
myCar.upgradeEngine(new Engine("Electric", 500));   // swap on the fly!
```
