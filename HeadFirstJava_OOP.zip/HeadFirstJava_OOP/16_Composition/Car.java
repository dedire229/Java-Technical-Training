// ============================================================
// 16 - COMPOSITION
// ============================================================
// "Favor composition over inheritance."
//                                  — Head First Design Patterns
//
// HAS-A relationship: a Car HAS-A Engine. A Room HAS-A Chair.
// Unlike inheritance (IS-A), composition lets you swap parts
// at runtime and avoid fragile parent-class coupling.
// ============================================================

class Engine {
    private String type;
    private int horsepower;

    public Engine(String type, int hp) {
        this.type = type;
        this.horsepower = hp;
    }

    public void start() {
        System.out.println(type + " engine (" + horsepower + "hp) starts: Vroom!");
    }

    public String getType() { return type; }
    public int getHorsepower() { return horsepower; }
}

class GPS {
    private String brand;
    public GPS(String brand) { this.brand = brand; }
    public void navigate(String address) {
        System.out.println(brand + " GPS: routing to " + address);
    }
}

// Car IS composed of Engine + GPS (and 4 Wheels, etc.)
class Car {
    private Engine engine;          // HAS-A
    private GPS    gps;             // HAS-A
    private String model;

    public Car(String model, Engine engine, GPS gps) {
        this.model  = model;
        this.engine = engine;
        this.gps    = gps;
    }

    public void drive(String address) {
        System.out.println("Driving the " + model + "...");
        engine.start();
        gps.navigate(address);
    }

    // Swap engine at runtime — flexibility inheritance can't give you
    public void upgradeEngine(Engine newEngine) {
        System.out.println("Swapping " + engine.getType() +
                           " for " + newEngine.getType() + ".");
        this.engine = newEngine;
    }
}

class CompositionDemo {
    public static void main(String[] args) {
        Engine v6 = new Engine("V6", 300);
        GPS    tomtom = new GPS("TomTom");

        Car myCar = new Car("Sedan X", v6, tomtom);
        myCar.drive("123 Main St");

        System.out.println();
        Engine electric = new Engine("Electric", 500);
        myCar.upgradeEngine(electric);
        myCar.drive("456 Oak Ave");
    }
}
