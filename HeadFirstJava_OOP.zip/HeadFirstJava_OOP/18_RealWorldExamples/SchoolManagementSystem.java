// ============================================================
// 18 - REAL WORLD EXAMPLE: SCHOOL MANAGEMENT SYSTEM
// ============================================================
// Puts together EVERYTHING from previous folders:
//   • Classes & Objects      — Person, Student, Teacher
//   • Encapsulation          — private fields with getters
//   • Inheritance            — Person → Student/Teacher
//   • Polymorphism           — introduce() behaves per subtype
//   • Abstraction            — abstract Person class
//   • Interfaces             — Teachable, Gradeable contracts
//   • Composition            — School has Classrooms
//   • Polymorphic collections — List<Person> holding mixed types
// ============================================================

import java.util.ArrayList;
import java.util.List;

// ---- Abstraction ----
abstract class Person {
    private String name;
    private int    age;

    public Person(String name, int age) {
        this.name = name;
        this.age  = age;
    }

    public String getName() { return name; }
    public int    getAge()  { return age;  }

    public abstract void introduce();   // polymorphic

    // Common behavior for everyone
    public void attend(String event) {
        System.out.println(name + " attends " + event);
    }
}

// ---- Interface contracts ----
interface Teachable {
    void teach(String topic);
}
interface Gradeable {
    void receiveGrade(String subject, char grade);
}

// ---- Inheritance ----
class Student extends Person implements Gradeable {
    private List<String> courses = new ArrayList<>();

    public Student(String name, int age) { super(name, age); }

    public void enroll(String course) { courses.add(course); }

    @Override
    public void introduce() {
        System.out.println("Hi, I'm student " + getName() +
                           ", age " + getAge() +
                           ", taking " + courses);
    }

    @Override
    public void receiveGrade(String subject, char grade) {
        System.out.println(getName() + " got " + grade + " in " + subject);
    }
}

class Teacher extends Person implements Teachable, Gradeable {
    private String subject;

    public Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }

    @Override
    public void introduce() {
        System.out.println("I'm teacher " + getName() +
                           ", age " + getAge() +
                           ", teaching " + subject);
    }

    @Override
    public void teach(String topic) {
        System.out.println(getName() + " teaches: " + topic);
    }

    @Override
    public void receiveGrade(String subject, char grade) {
        // A teacher receiving a performance review grade
        System.out.println(getName() + " (teacher) review in " +
                           subject + " → " + grade);
    }
}

// ---- Composition ----
class Classroom {
    private String roomNumber;
    private List<Person> occupants = new ArrayList<>();

    public Classroom(String roomNumber) { this.roomNumber = roomNumber; }

    public void enter(Person p) {
        occupants.add(p);
        System.out.println(p.getName() + " enters room " + roomNumber);
    }

    public void roster() {
        System.out.println("\nRoster for room " + roomNumber + ":");
        for (Person p : occupants) p.introduce();  // polymorphism in action
    }
}

// ---- Driver ----
public class SchoolManagementSystem {
    public static void main(String[] args) {
        Classroom room101 = new Classroom("101");

        Student alice = new Student("Alice", 16);
        alice.enroll("Math");
        alice.enroll("Physics");

        Student bob   = new Student("Bob", 17);
        bob.enroll("History");

        Teacher msK   = new Teacher("Ms. K", 35, "Math");
        Teacher mrH   = new Teacher("Mr. H", 42, "History");

        // Enter people — both Student and Teacher fit in Person
        room101.enter(alice);
        room101.enter(bob);
        room101.enter(msK);
        room101.enter(mrH);

        // Polymorphic roster — each introduces differently
        room101.roster();

        // Use interface contracts
        System.out.println();
        msK.teach("Quadratic equations");
        mrH.teach("World War II");

        alice.receiveGrade("Math",    'A');
        bob.receiveGrade("History",  'B');
        msK.receiveGrade("Math",     'A');   // teacher review
    }
}
