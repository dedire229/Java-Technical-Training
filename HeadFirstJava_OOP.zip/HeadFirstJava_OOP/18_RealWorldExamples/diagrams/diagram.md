# 18 — Real-World Example: School Management System

## Concept
Puts together **every** OOP concept from previous folders into a single coherent design.

## Diagram

```
                       ┌──────────────────────────────────────┐
                       │  «abstract» Person                  │
                       ├──────────────────────────────────────┤
                       │ - name : String                     │
                       │ - age  : int                        │
                       ├──────────────────────────────────────┤
                       │ + getName() / getAge()              │
                       │ + attend(event) : void              │
                       │ + introduce() : void   «abstract»   │
                       └──────────┬───────────────┬──────────┘
                                  │               │
                          extends │               │ extends
                                  │               │
                                  ▼               ▼
                       ┌────────────────────┐  ┌──────────────────────┐
                       │      Student       │  │       Teacher        │
                       ├────────────────────┤  ├──────────────────────┤
                       │ - courses : List   │  │ - subject : String   │
                       ├────────────────────┤  ├──────────────────────┤
                       │ + enroll(c)        │  │ + teach(topic)       │
                       │ + introduce()      │  │ + introduce()        │
                       └─────┬──────────────┘  └──────┬───────────────┘
                             │                       │
                ─────────────┤           ────────────┼────────────
                implements   │           implements   │  implements
                             ▼                       ▼
                       ┌──────────────────────────────────────┐
                       │       «interface» Gradeable          │
                       ├──────────────────────────────────────┤
                       │ + receiveGrade(subject, grade)       │
                       └──────────────────────────────────────┘


                                  «interface»
                       ┌──────────────────────────────────────┐
                       │        Teachable                    │
                       ├──────────────────────────────────────┤
                       │ + teach(topic) : void               │
                       └──────────────────────────────────────┘


                       ┌──────────────────────────────────────┐
                       │        Classroom                    │
                       ├──────────────────────────────────────┤
                       │ - roomNumber : String               │
                       │ - occupants  : List<Person>         │  ◄── composition
                       ├──────────────────────────────────────┤
                       │ + enter(p : Person) : void          │
                       │ + roster() : void                   │
                       └──────────────────────────────────────┘
                                       ▲
                                       │ HAS-A  (1 ───── *)
                                       │
                                       │ contains any Person
                                       │
                                  School (omitted)
```

### Concepts in action

| OOP concept | Where |
|---|---|
| Abstraction | `abstract Person`, `abstract introduce()` |
| Encapsulation | private fields + getters |
| Inheritance | `Student` and `Teacher` extend `Person` |
| Polymorphism | `person.introduce()` behaves differently per subtype |
| Interfaces | `Gradeable`, `Teachable` define contracts |
| Composition | `Classroom` contains `List<Person>` |
| Polymorphic collection | `List<Person>` holds both Students and Teachers |
